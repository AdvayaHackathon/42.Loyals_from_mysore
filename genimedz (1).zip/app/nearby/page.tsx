import type { Metadata } from "next"
import Link from "next/link"
import { ArrowLeft, MapPin, Navigation, Phone, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export const metadata: Metadata = {
  title: "Find Nearby Stores - GeniMedz",
  description: "Locate stores near you that have your medicine in stock",
}

export default function NearbyPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="gap-1" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[350px_1fr]">
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Find Nearby Stores</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label htmlFor="location" className="text-sm font-medium mb-1 block">
                  Your Location
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input id="location" placeholder="Enter your location" className="pl-8" />
                  </div>
                  <Button variant="outline" size="icon">
                    <Navigation className="h-4 w-4" />
                    <span className="sr-only">Use current location</span>
                  </Button>
                </div>
              </div>

              <div>
                <label htmlFor="medicine" className="text-sm font-medium mb-1 block">
                  Medicine (Optional)
                </label>
                <Input id="medicine" placeholder="Enter medicine name" />
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Distance</label>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" size="sm" className="bg-emerald-50 border-emerald-200 text-emerald-700">
                    1 km
                  </Button>
                  <Button variant="outline" size="sm">
                    3 km
                  </Button>
                  <Button variant="outline" size="sm">
                    5 km
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Store Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" className="bg-emerald-50 border-emerald-200 text-emerald-700">
                    All Stores
                  </Button>
                  <Button variant="outline" size="sm">
                    24/7 Open
                  </Button>
                </div>
              </div>

              <Button className="w-full">Search Stores</Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-950 p-4 rounded-lg border">
            <div className="aspect-video w-full bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center mb-4">
              <MapPin className="h-12 w-12 text-gray-400" />
              <span className="sr-only">Map placeholder</span>
            </div>
            <p className="text-sm text-gray-500 text-center">Map showing nearby pharmacies and medical stores</p>
          </div>

          <h2 className="text-xl font-semibold">Nearby Stores (5 found)</h2>

          <div className="grid gap-4">
            {[
              {
                name: "MediPlus Pharmacy",
                distance: "0.5 km",
                address: "123 Health Street, Medical District",
                phone: "+91 98765 43210",
                open: true,
                rating: 4.8,
                hasStock: true,
              },
              {
                name: "City Medicals",
                distance: "0.8 km",
                address: "456 Wellness Avenue, Central Area",
                phone: "+91 98765 12345",
                open: true,
                rating: 4.5,
                hasStock: true,
              },
              {
                name: "HealthMart Store",
                distance: "1.2 km",
                address: "789 Care Road, Health Zone",
                phone: "+91 98765 67890",
                open: false,
                rating: 4.2,
                hasStock: false,
              },
              {
                name: "Wellness Pharmacy",
                distance: "1.5 km",
                address: "321 Medicine Lane, Pharma Park",
                phone: "+91 98765 09876",
                open: true,
                rating: 4.6,
                hasStock: true,
              },
              {
                name: "Care & Cure",
                distance: "1.8 km",
                address: "654 Remedy Street, Health Hub",
                phone: "+91 98765 54321",
                open: true,
                rating: 4.3,
                hasStock: false,
              },
            ].map((store, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{store.name}</CardTitle>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <MapPin className="h-3 w-3" />
                        {store.distance} away
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{store.rating}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">{store.address}</p>
                  <div className="flex flex-wrap gap-2">
                    {store.open ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Open Now
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                        Closed
                      </Badge>
                    )}

                    {store.hasStock ? (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        In Stock
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-gray-100 text-gray-700 border-gray-200">
                        Stock Unknown
                      </Badge>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Phone className="h-4 w-4" />
                    {store.phone}
                  </Button>
                  <Button size="sm" className="gap-1">
                    <Navigation className="h-4 w-4" />
                    Directions
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

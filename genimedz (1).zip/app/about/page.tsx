import type { Metadata } from "next"
import Link from "next/link"
import { ArrowLeft, CheckCircle, FileText, Users, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export const metadata: Metadata = {
  title: "About GeniMedz - Same Cure, Smarter Price",
  description: "Learn about GeniMedz and our mission to make medicine more affordable",
}

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="gap-1" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">About GeniMedz</h1>
          <p className="text-xl text-gray-500">Cut the Cost, Not the Care.</p>
        </div>

        <div className="prose prose-emerald dark:prose-invert max-w-none mb-12">
          <p className="lead">
            GeniMedz is a platform dedicated to helping people find affordable medicine alternatives with identical
            compositions. We believe that everyone deserves access to affordable healthcare without compromising on
            quality.
          </p>

          <h2>Our Mission</h2>
          <p>
            Our mission is to empower consumers with information about medicine alternatives, enabling them to make
            informed decisions about their healthcare spending. By providing transparent price comparisons for medicines
            with identical compositions, we help people save money without sacrificing the quality of their treatment.
          </p>

          <h2>How We Help</h2>
          <div className="grid gap-6 md:grid-cols-3 my-8">
            <Card>
              <CardHeader className="pb-2">
                <CheckCircle className="h-8 w-8 text-emerald-500 mb-2" />
                <CardTitle className="text-lg">Verified Information</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  We only list medicines that are approved by regulatory authorities like CDSCO, ensuring safety and
                  efficacy.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <FileText className="h-8 w-8 text-emerald-500 mb-2" />
                <CardTitle className="text-lg">Detailed Comparisons</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  Compare prices, availability, and other factors to find the best option for your needs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <MapPin className="h-8 w-8 text-emerald-500 mb-2" />
                <CardTitle className="text-lg">Store Locator</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  Find nearby stores that have your medicine in stock, saving you time and effort.
                </p>
              </CardContent>
            </Card>
          </div>

          <h2>Our Data Sources</h2>
          <p>We gather information from official sources, including:</p>
          <ul>
            <li>Central Drugs Standard Control Organization (CDSCO)</li>
            <li>National Pharmaceutical Pricing Authority (NPPA)</li>
            <li>Pharmacy databases and authorized distributors</li>
            <li>Direct partnerships with pharmacies and medical stores</li>
          </ul>

          <h2>Privacy & Security</h2>
          <p>
            We take your privacy seriously. When you use our location services or upload prescription images, we
            implement strict security measures to protect your data. Your prescription images are processed securely and
            are not stored permanently on our servers.
          </p>

          <Separator className="my-8" />

          <div className="bg-gray-50 dark:bg-gray-900 p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Disclaimer</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              GeniMedz provides information for educational purposes only. We do not provide medical advice, diagnosis,
              or treatment. Always consult with a qualified healthcare provider before making any decisions about your
              health or medication. The information about medicine compositions and prices is collected from reliable
              sources, but we recommend verifying with your healthcare provider or pharmacist before making any changes
              to your medication.
            </p>
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Our Team</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full bg-gray-200 mb-4 flex items-center justify-center">
                    <Users className="h-12 w-12 text-gray-400" />
                  </div>
                  <h3 className="font-bold">Dr. Anil Sharma</h3>
                  <p className="text-sm text-gray-500">Founder & Medical Director</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full bg-gray-200 mb-4 flex items-center justify-center">
                    <Users className="h-12 w-12 text-gray-400" />
                  </div>
                  <h3 className="font-bold">Priya Patel</h3>
                  <p className="text-sm text-gray-500">Chief Technology Officer</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full bg-gray-200 mb-4 flex items-center justify-center">
                    <Users className="h-12 w-12 text-gray-400" />
                  </div>
                  <h3 className="font-bold">DIVYA GOWDA</h3>
                  <p className="text-sm text-gray-500">Head of Partnerships</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
          <p className="mb-6">Have questions or feedback? We'd love to hear from you!</p>
          <Button size="lg" asChild>
            <Link href="/contact">Get in Touch</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

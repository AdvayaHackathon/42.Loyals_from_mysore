import type { Metadata } from "next"
import Link from "next/link"
import { ArrowLeft, ExternalLink, MapPin, ShoppingBag, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Medicine Comparison - GeniMedz",
  description: "Compare medicine prices and find affordable alternatives with the same composition",
}

export default function MedicineComparePage({ params }: { params: { medicine: string } }) {
  // In a real app, we would fetch this data from an API based on the medicine parameter
  const medicineData = {
    name: params.medicine.charAt(0).toUpperCase() + params.medicine.slice(1),
    composition: "Paracetamol 500mg",
    description:
      "Used for the treatment of mild to moderate pain and fever. It works by inhibiting the production of certain chemical messengers in the brain that cause pain and fever.",
    sideEffects: "Nausea, stomach pain, loss of appetite, headache, dizziness",
    dosage: "1-2 tablets every 4-6 hours as needed, not exceeding 8 tablets in 24 hours",
    approvals: ["CDSCO", "FDA", "EMA"],
    alternatives: [
      {
        brand: "Crocin",
        manufacturer: "GSK",
        price: "₹22",
        packSize: "10 tablets",
        pricePerUnit: "₹2.2/tablet",
        availability: "High",
        rating: 4.5,
      },
      {
        brand: "Dolo",
        manufacturer: "Micro Labs",
        price: "₹30",
        packSize: "15 tablets",
        pricePerUnit: "₹2.0/tablet",
        availability: "High",
        rating: 4.7,
      },
      {
        brand: "Paracip",
        manufacturer: "Cipla",
        price: "₹18",
        packSize: "10 tablets",
        pricePerUnit: "₹1.8/tablet",
        availability: "Medium",
        rating: 4.3,
      },
      {
        brand: "Febrinil",
        manufacturer: "Alkem",
        price: "₹15",
        packSize: "10 tablets",
        pricePerUnit: "₹1.5/tablet",
        availability: "Low",
        rating: 4.0,
      },
      {
        brand: "P-500",
        manufacturer: "Apex",
        price: "₹12",
        packSize: "10 tablets",
        pricePerUnit: "₹1.2/tablet",
        availability: "Medium",
        rating: 3.8,
      },
    ],
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="gap-1" asChild>
          <Link href="/compare">
            <ArrowLeft className="h-4 w-4" />
            Back to Compare
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold">{medicineData.name}</h1>
              <p className="text-gray-500">{medicineData.composition}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {medicineData.approvals.map((approval, index) => (
                <Badge key={index} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  {approval} Approved
                </Badge>
              ))}
            </div>
          </div>

          <Tabs defaultValue="alternatives" className="mb-8">
            <TabsList>
              <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
              <TabsTrigger value="info">Medicine Info</TabsTrigger>
            </TabsList>

            <TabsContent value="alternatives" className="mt-4">
              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg mb-6">
                <h3 className="font-medium mb-2">Cut the Cost, Not the Care.</h3>
                <p className="text-sm text-gray-500">
                  All alternatives listed below contain the exact same active ingredient and are approved by regulatory
                  authorities. The price difference is often due to brand value, marketing costs, and packaging.
                </p>
              </div>

              <div className="grid gap-4">
                {medicineData.alternatives.map((alt, index) => (
                  <Card
                    key={index}
                    className={index === 0 ? "border-emerald-200 bg-emerald-50/30 dark:bg-emerald-950/10" : ""}
                  >
                    {index === 0 && (
                      <div className="bg-emerald-500 text-white text-xs font-medium px-3 py-1 absolute right-4 top-0 rounded-b-md">
                        Best Value
                      </div>
                    )}
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl">{alt.brand}</CardTitle>
                          <p className="text-sm text-gray-500">{alt.manufacturer}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">{alt.price}</div>
                          <p className="text-xs text-gray-500">{alt.pricePerUnit}</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Pack Size</p>
                          <p className="font-medium">{alt.packSize}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Availability</p>
                          <p className="font-medium">{alt.availability}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Rating</p>
                          <div className="flex items-center">
                            <ThumbsUp className="h-4 w-4 text-emerald-500 mr-1" />
                            <span className="font-medium">{alt.rating}/5</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button variant="outline" size="sm" className="gap-1">
                        <MapPin className="h-4 w-4" />
                        Find Nearby
                      </Button>
                      <Button size="sm" className="gap-1">
                        <ShoppingBag className="h-4 w-4" />
                        Buy Online
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="info" className="mt-4">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Description</h3>
                      <p className="text-gray-700 dark:text-gray-300">{medicineData.description}</p>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-semibold mb-2">Dosage</h3>
                      <p className="text-gray-700 dark:text-gray-300">{medicineData.dosage}</p>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-semibold mb-2">Side Effects</h3>
                      <p className="text-gray-700 dark:text-gray-300">{medicineData.sideEffects}</p>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-semibold mb-2">Regulatory Approvals</h3>
                      <div className="flex flex-wrap gap-2">
                        {medicineData.approvals.map((approval, index) => (
                          <Badge key={index} variant="outline">
                            {approval}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4">
                      <p className="text-sm text-gray-500">
                        Disclaimer: This information is for educational purposes only and is not intended as medical
                        advice. Always consult with a healthcare professional before taking any medication.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Similar Medicines</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              <Link href="/compare/ibuprofen" className="text-sm hover:underline flex justify-between">
                Ibuprofen <ExternalLink className="h-4 w-4" />
              </Link>
              <Link href="/compare/aspirin" className="text-sm hover:underline flex justify-between">
                Aspirin <ExternalLink className="h-4 w-4" />
              </Link>
              <Link href="/compare/naproxen" className="text-sm hover:underline flex justify-between">
                Naproxen <ExternalLink className="h-4 w-4" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Find Nearby Stores</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">
                Locate stores near you that have {medicineData.name} or its alternatives in stock
              </p>
              <Button className="w-full gap-1">
                <MapPin className="h-4 w-4" />
                Find Nearby Stores
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

import type { Metadata } from "next"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Compare Medicines - GeniMedz",
  description: "Compare medicine prices and find affordable alternatives with the same composition",
}

export default function ComparePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="gap-1" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>

      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Compare Medicine Prices</h1>

        <div className="mb-8">
          <div className="relative">
            <Input
              type="search"
              placeholder="Search for a medicine to compare..."
              className="w-full pl-4 pr-10 py-6 text-lg"
            />
            <Button className="absolute right-1 top-1">Search</Button>
          </div>
          <p className="text-sm text-gray-500 mt-2">Enter medicine name, composition, or brand to find alternatives</p>
        </div>

        <h2 className="text-xl font-semibold mb-4">Popular Comparisons</h2>

        <Tabs defaultValue="pain">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="pain">Pain Relief</TabsTrigger>
            <TabsTrigger value="antibiotics">Antibiotics</TabsTrigger>
            <TabsTrigger value="diabetes">Diabetes</TabsTrigger>
            <TabsTrigger value="hypertension">Hypertension</TabsTrigger>
          </TabsList>

          <TabsContent value="pain" className="space-y-4">
            {[
              { name: "Paracetamol", composition: "Acetaminophen 500mg", alternatives: 12 },
              { name: "Ibuprofen", composition: "Ibuprofen 400mg", alternatives: 8 },
              { name: "Diclofenac", composition: "Diclofenac Sodium 50mg", alternatives: 15 },
            ].map((medicine, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{medicine.name}</CardTitle>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {medicine.alternatives} alternatives
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-sm text-gray-500">{medicine.composition}</p>
                  <Button asChild variant="link" className="p-0 h-auto mt-2">
                    <Link href={`/compare/${medicine.name.toLowerCase()}`}>Compare prices</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="antibiotics" className="space-y-4">
            {[
              { name: "Azithromycin", composition: "Azithromycin 500mg", alternatives: 10 },
              { name: "Amoxicillin", composition: "Amoxicillin 500mg", alternatives: 14 },
              { name: "Ciprofloxacin", composition: "Ciprofloxacin 500mg", alternatives: 9 },
            ].map((medicine, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{medicine.name}</CardTitle>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {medicine.alternatives} alternatives
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-sm text-gray-500">{medicine.composition}</p>
                  <Button asChild variant="link" className="p-0 h-auto mt-2">
                    <Link href={`/compare/${medicine.name.toLowerCase()}`}>Compare prices</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="diabetes" className="space-y-4">
            {[
              { name: "Metformin", composition: "Metformin 500mg", alternatives: 16 },
              { name: "Glimepiride", composition: "Glimepiride 2mg", alternatives: 11 },
              { name: "Sitagliptin", composition: "Sitagliptin 100mg", alternatives: 7 },
            ].map((medicine, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{medicine.name}</CardTitle>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {medicine.alternatives} alternatives
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-sm text-gray-500">{medicine.composition}</p>
                  <Button asChild variant="link" className="p-0 h-auto mt-2">
                    <Link href={`/compare/${medicine.name.toLowerCase()}`}>Compare prices</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="hypertension" className="space-y-4">
            {[
              { name: "Amlodipine", composition: "Amlodipine 5mg", alternatives: 13 },
              { name: "Losartan", composition: "Losartan 50mg", alternatives: 9 },
              { name: "Telmisartan", composition: "Telmisartan 40mg", alternatives: 12 },
            ].map((medicine, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{medicine.name}</CardTitle>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {medicine.alternatives} alternatives
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <p className="text-sm text-gray-500">{medicine.composition}</p>
                  <Button asChild variant="link" className="p-0 h-auto mt-2">
                    <Link href={`/compare/${medicine.name.toLowerCase()}`}>Compare prices</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

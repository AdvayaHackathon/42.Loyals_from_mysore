import type { Metadata } from "next"
import Link from "next/link"
import { ArrowLeft, Filter, SearchIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"

export const metadata: Metadata = {
  title: "Search Results - GeniMedz",
  description: "Search results for medicines on GeniMedz",
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string; mode?: string }
}) {
  const query = searchParams.q || ""
  const mode = searchParams.mode || "text"

  // Mock search results - in a real app, these would come from an API
  const searchResults = [
    {
      name: "Paracetamol",
      composition: "Acetaminophen 500mg",
      category: "Pain Relief",
      brands: 12,
      priceRange: "₹10 - ₹45",
      approved: true,
    },
    {
      name: "Paracetamol + Caffeine",
      composition: "Acetaminophen 500mg + Caffeine 65mg",
      category: "Pain Relief",
      brands: 8,
      priceRange: "₹25 - ₹60",
      approved: true,
    },
    {
      name: "Paracip",
      composition: "Acetaminophen 500mg",
      category: "Pain Relief",
      brands: 1,
      priceRange: "₹18",
      approved: true,
    },
    {
      name: "Dolo 650",
      composition: "Acetaminophen 650mg",
      category: "Pain Relief",
      brands: 1,
      priceRange: "₹30",
      approved: true,
    },
    {
      name: "Crocin",
      composition: "Acetaminophen 500mg",
      category: "Pain Relief",
      brands: 1,
      priceRange: "₹22",
      approved: true,
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="gap-1" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[250px_1fr]">
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-sm font-medium mb-3">Categories</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="pain" checked />
                    <label htmlFor="pain" className="text-sm">
                      Pain Relief
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="fever" />
                    <label htmlFor="fever" className="text-sm">
                      Fever
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="cold" />
                    <label htmlFor="cold" className="text-sm">
                      Cold & Flu
                    </label>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-medium mb-3">Price Range</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price1" />
                    <label htmlFor="price1" className="text-sm">
                      Under ₹20
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price2" checked />
                    <label htmlFor="price2" className="text-sm">
                      ₹20 - ₹50
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price3" />
                    <label htmlFor="price3" className="text-sm">
                      ₹50 - ₹100
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="price4" />
                    <label htmlFor="price4" className="text-sm">
                      Above ₹100
                    </label>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-medium mb-3">Approvals</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="cdsco" checked />
                    <label htmlFor="cdsco" className="text-sm">
                      CDSCO Approved
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="fda" />
                    <label htmlFor="fda" className="text-sm">
                      FDA Approved
                    </label>
                  </div>
                </div>
              </div>

              <Button className="w-full">Apply Filters</Button>
            </CardContent>
          </Card>
        </div>

        <div>
          <div className="mb-6">
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
              <h1 className="text-2xl font-bold">
                {mode === "photo" ? "Photo Search Results" : `Search Results for "${query}"`}
              </h1>
              <Badge className="w-fit">{searchResults.length} results found</Badge>
            </div>

            {mode === "photo" && (
              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg mb-6 flex items-center gap-4">
                <div className="w-16 h-16 bg-gray-200 rounded flex items-center justify-center shrink-0">
                  <SearchIcon className="h-8 w-8 text-gray-400" />
                </div>
                <div>
                  <h3 className="font-medium">Prescription Photo Analysis</h3>
                  <p className="text-sm text-gray-500">
                    We've analyzed your prescription and found the following medicines. Click on any result to see
                    alternatives and compare prices.
                  </p>
                </div>
              </div>
            )}

            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="relative w-full md:w-auto md:flex-1 max-w-sm">
                <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input type="search" placeholder="Refine your search..." className="pl-8" defaultValue={query} />
              </div>
              <Button variant="outline" size="sm" className="w-full md:w-auto gap-1">
                <Filter className="h-4 w-4" />
                Sort by: Relevance
              </Button>
            </div>
          </div>

          <div className="grid gap-4">
            {searchResults.map((result, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{result.name}</CardTitle>
                      <p className="text-sm text-gray-500">{result.composition}</p>
                    </div>
                    {result.approved && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        CDSCO Approved
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Category</p>
                      <p className="font-medium">{result.category}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Brands/Variants</p>
                      <p className="font-medium">{result.brands}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Price Range</p>
                      <p className="font-medium">{result.priceRange}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full sm:w-auto">
                    <Link href={`/compare/${result.name.toLowerCase().replace(/\s+/g, "-")}`}>Compare Prices</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

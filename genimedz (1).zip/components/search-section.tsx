"use client"

import type React from "react"

import { useState } from "react"
import { Search, Camera, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"

export function SearchSection() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [location, setLocation] = useState("")
  const [isLocating, setIsLocating] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setSelectedFile(file)

      // Create preview URL
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handlePhotoSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedFile) {
      // In a real app, this would upload the image and process it
      router.push("/search?mode=photo")
    }
  }

  const getCurrentLocation = () => {
    setIsLocating(true)
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In a real app, we would use these coordinates to get the address
          setLocation("Current location detected")
          setIsLocating(false)
        },
        (error) => {
          console.error("Error getting location:", error)
          setLocation("Could not get location")
          setIsLocating(false)
        },
      )
    } else {
      setLocation("Geolocation not supported by your browser")
      setIsLocating(false)
    }
  }

  const handleLocationSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (location) {
      router.push(`/nearby?location=${encodeURIComponent(location)}`)
    }
  }

  return (
    <div className="w-full max-w-3xl mx-auto mt-8">
      <Tabs defaultValue="text" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="text">Text Search</TabsTrigger>
          <TabsTrigger value="photo">Photo Search</TabsTrigger>
          <TabsTrigger value="location">Find Nearby</TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="mt-4">
          <form onSubmit={handleSearch} className="flex w-full max-w-lg space-x-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input
                type="search"
                placeholder="Search for medicines by name..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button type="submit">Search</Button>
          </form>
          <p className="mt-2 text-sm text-gray-500">Example: Paracetamol, Ibuprofen, Aspirin</p>
        </TabsContent>

        <TabsContent value="photo" className="mt-4">
          <form onSubmit={handlePhotoSearch} className="space-y-4">
            <div className="grid w-full max-w-lg gap-2">
              <label
                htmlFor="picture"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Upload prescription image
              </label>

              {previewUrl ? (
                <div className="relative aspect-video w-full max-w-lg overflow-hidden rounded-lg border border-dashed">
                  <img
                    src={previewUrl || "/placeholder.svg"}
                    alt="Prescription preview"
                    className="h-full w-full object-contain"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="absolute right-2 top-2"
                    onClick={() => {
                      setSelectedFile(null)
                      setPreviewUrl(null)
                    }}
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <label
                  htmlFor="picture"
                  className="flex aspect-video w-full max-w-lg cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed"
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Camera className="mb-2 h-8 w-8 text-gray-500 dark:text-gray-400" />
                    <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG or JPEG (MAX. 5MB)</p>
                  </div>
                  <Input id="picture" type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                </label>
              )}
            </div>
            <Button type="submit" disabled={!selectedFile}>
              Search with Photo
            </Button>
          </form>
          <p className="mt-2 text-sm text-gray-500">Upload a clear image of your prescription for better results</p>
        </TabsContent>

        <TabsContent value="location" className="mt-4">
          <form onSubmit={handleLocationSearch} className="space-y-4">
            <div className="flex w-full max-w-lg space-x-2">
              <div className="relative flex-1">
                <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Input
                  type="text"
                  placeholder="Enter your location..."
                  className="w-full pl-8"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              <Button type="button" variant="outline" onClick={getCurrentLocation} disabled={isLocating}>
                {isLocating ? "Detecting..." : "Use Current"}
              </Button>
            </div>
            <Button type="submit" disabled={!location}>
              Find Nearby Stores
            </Button>
          </form>
          <p className="mt-2 text-sm text-gray-500">Find stores with your medicine nearby</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}

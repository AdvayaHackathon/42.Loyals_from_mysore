import { Search, FileText, MapPin, Percent } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: <Search className="h-10 w-10 text-emerald-500" />,
      title: "Search Medicine",
      description: "Search for your medicine by name or upload a prescription photo",
    },
    {
      icon: <FileText className="h-10 w-10 text-emerald-500" />,
      title: "Compare Options",
      description: "View all available alternatives with identical compositions",
    },
    {
      icon: <Percent className="h-10 w-10 text-emerald-500" />,
      title: "Save Money",
      description: "Choose the most affordable option that suits your needs",
    },
    {
      icon: <MapPin className="h-10 w-10 text-emerald-500" />,
      title: "Find Nearby",
      description: "Locate stores near you that have your medicine in stock",
    },
  ]

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900 rounded-xl my-12">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How GeniMedz Works</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Find affordable medicine alternatives in just a few simple steps
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 bg-white dark:bg-gray-800 rounded-full shadow-md">{step.icon}</div>
              <h3 className="text-xl font-bold">{step.title}</h3>
              <p className="text-gray-500 dark:text-gray-400">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

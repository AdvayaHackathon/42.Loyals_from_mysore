"use client"

import { useEffect, useRef } from "react"

export default function Chart() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setDimensions = () => {
      const parent = canvas.parentElement
      if (parent) {
        canvas.width = parent.clientWidth
        canvas.height = parent.clientHeight
      }
    }

    setDimensions()
    window.addEventListener("resize", setDimensions)

    // Sample data - visitors over time
    const data = [
      12000, 15000, 18000, 22000, 19000, 24000, 28000, 32000, 30000, 35000, 38000, 42000, 45000, 48000, 52000, 55000,
      58000, 62000, 65000, 68000, 72000, 75000, 78000, 82000, 85000, 88000, 92000, 95000, 98000, 102000,
    ]

    // Draw chart
    const drawChart = () => {
      if (!ctx) return

      const width = canvas.width
      const height = canvas.height
      const padding = 20
      const chartWidth = width - padding * 2
      const chartHeight = height - padding * 2

      // Clear canvas
      ctx.clearRect(0, 0, width, height)

      // Find min and max values
      const maxValue = Math.max(...data) * 1.1
      const minValue = Math.min(...data) * 0.9

      // Draw gradient
      const gradient = ctx.createLinearGradient(0, padding, 0, height - padding)
      gradient.addColorStop(0, "rgba(16, 185, 129, 0.2)")
      gradient.addColorStop(1, "rgba(16, 185, 129, 0)")

      // Draw line and fill
      ctx.beginPath()
      ctx.moveTo(padding, height - padding - ((data[0] - minValue) / (maxValue - minValue)) * chartHeight)

      // Draw points
      data.forEach((value, index) => {
        const x = padding + (index / (data.length - 1)) * chartWidth
        const y = height - padding - ((value - minValue) / (maxValue - minValue)) * chartHeight
        ctx.lineTo(x, y)
      })

      // Complete the fill area
      ctx.lineTo(width - padding, height - padding)
      ctx.lineTo(padding, height - padding)
      ctx.closePath()

      // Fill with gradient
      ctx.fillStyle = gradient
      ctx.fill()

      // Draw the line
      ctx.beginPath()
      ctx.moveTo(padding, height - padding - ((data[0] - minValue) / (maxValue - minValue)) * chartHeight)

      data.forEach((value, index) => {
        const x = padding + (index / (data.length - 1)) * chartWidth
        const y = height - padding - ((value - minValue) / (maxValue - minValue)) * chartHeight
        ctx.lineTo(x, y)
      })

      ctx.strokeStyle = "#10b981"
      ctx.lineWidth = 2
      ctx.stroke()
    }

    drawChart()
    window.addEventListener("resize", drawChart)

    return () => {
      window.removeEventListener("resize", setDimensions)
      window.removeEventListener("resize", drawChart)
    }
  }, [])

  return <canvas ref={canvasRef} className="w-full h-full" />
}

import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function FeaturedMedicines() {
  const medicines = [
    {
      name: "Paracetamol",
      composition: "Acetaminophen 500mg",
      priceRange: "₹10 - ₹45",
      alternatives: 12,
      approved: true,
    },
    {
      name: "Azithromycin",
      composition: "Azithromycin 500mg",
      priceRange: "₹80 - ₹180",
      alternatives: 8,
      approved: true,
    },
    {
      name: "Montelukast",
      composition: "Montelukast 10mg",
      priceRange: "₹120 - ₹350",
      alternatives: 15,
      approved: true,
    },
    {
      name: "Amlodipine",
      composition: "Amlodipine 5mg",
      priceRange: "₹25 - ₹90",
      alternatives: 10,
      approved: true,
    },
  ]

  return (
    <section className="py-12">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter">Popular Comparisons</h2>
            <p className="text-gray-500 dark:text-gray-400">Most frequently compared medicines on GeniMedz</p>
          </div>
          <Button asChild variant="ghost" className="gap-1">
            <Link href="/compare">
              View all comparisons
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {medicines.map((medicine, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{medicine.name}</CardTitle>
                  {medicine.approved && (
                    <Badge
                      variant="outline"
                      className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800"
                    >
                      CDSCO Approved
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="grid gap-2">
                  <div className="text-sm">
                    <span className="font-medium">Composition:</span> {medicine.composition}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Price Range:</span> {medicine.priceRange}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Alternatives:</span> {medicine.alternatives} options
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild variant="ghost" className="w-full" size="sm">
                  <Link href={`/compare/${medicine.name.toLowerCase()}`}>Compare Prices</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

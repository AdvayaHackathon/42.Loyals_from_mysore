import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function Testimonials() {
  const testimonials = [
    {
      quote:
        "GeniMedz helped me find a more affordable alternative to my regular medication. I'm saving over 60% every month!",
      author: "Priya Sharma",
      role: "Delhi",
      avatar: "PS",
    },
    {
      quote:
        "The prescription photo search feature is incredible. I just took a picture and found all the alternatives instantly.",
      author: "Rahul Patel",
      role: "Mumbai",
      avatar: "RP",
    },
    {
      quote:
        "As a senior citizen on a fixed income, finding affordable medicine is crucial. GeniMedz has been a lifesaver.",
      author: "Anjali Desai",
      role: "Bangalore",
      avatar: "AD",
    },
  ]

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900 rounded-xl my-12">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Users Say</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Discover how GeniMedz is helping people save on their medicine costs
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white dark:bg-gray-800 border-none shadow-md">
              <CardContent className="pt-6">
                <div className="relative">
                  <span className="absolute -top-6 left-0 text-6xl text-emerald-200">"</span>
                  <blockquote className="relative z-10 text-lg italic">{testimonial.quote}</blockquote>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4 flex items-center gap-4">
                <Avatar>
                  <AvatarFallback className="bg-emerald-100 text-emerald-700">{testimonial.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{testimonial.role}</p>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
